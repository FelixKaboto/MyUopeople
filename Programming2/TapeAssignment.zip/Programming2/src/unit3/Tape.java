package unit3;
/**
 * This class implements double linked lists to solve the turing tape assignment
 * The tape is made up of little squares called cells lined up in a horizontal
 * row that stretches, conceptually, off to infinity in both directions.
 * Each cell can hold one character. Initially, the content of a cell is a blank space.
 * One cell on the tape is considered to be the current cell. 
 * This is the cell where the machine is located. As a 
 * Turing machine computes, it moves back and forth along the tape,
 * and the current cell changes. 
 * @author lein
 *
 */
public class Tape {
    private Cell runner;
    Tape(){
        Cell newCell = new Cell();
        newCell.content = ' ';
        newCell.prev = null;
        newCell.next = null;
        runner = newCell;
    }
    /*
     * this method returns the pointer that points to the current cell
     */
    public Cell getCurrentCell() {
        
        return runner;
    }
    /*
     *this method returns the char from the current cell 
     */
    public char getContent() {
        
        return runner.content;
    }
    /*
     * this method changes the char in the current cell to the specified value. 
     */
    public void setContent(char c) {
        
        runner.content = c;
        
    }
    
    public void moveLeft() {
        if (runner.prev == null) {
            Cell newCell = new Cell();
            newCell.content = ' ';
            newCell.prev = null;
            newCell.next = runner;
            runner.prev = newCell;            
        }
        runner = runner.prev;
    }
    
    public void moveRight() {
        if (runner.next == null) {
            Cell newCell = new Cell();
            newCell.content = ' ';
            newCell.next = null;
            newCell.prev = runner;
            runner.next = newCell;            
        }
        runner = runner.next;
    }
    /*
     * returns a String consisting of the chars from all the cells on the tape, 
     * read from left to right, except that leading or trailing blank characters should be discarded. 
     * The current cell pointer should not be moved by this method;
     * it should point to the same cell after the method is called as it did before
     */
    public String getTapeContents() { 
        Cell pointer = runner;
        while (pointer.prev != null)
            pointer = pointer.prev;
        String strContent = "";
        while (pointer != null) {
            strContent += pointer.content;
            pointer = pointer.next;
        }
        strContent = strContent.trim();
        return strContent;
    }
    

}
